#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

#include <elf.h>
#include <mbuf.h>
#include <relso.h>

#include <gdbrpc.h>

#define	ALIGN(k, v)	(((k)+((v) -1))&~((v)-1))
#define	STRCMP(a, R, b)	(strcmp(a, b) R 0)

struct r_so_resolv {
	Elf32_Sym	* symtab;
	Elf32_Word	* hash;
	Elf32_Word	* chain;
	Elf32_Word	  nbuckets;
	Elf32_Word	  nchains;
	char		* strtab;
};

struct r_so {
	void	* base;
	mbuf_t	* bp;
	mbuf_t	* file;
	Elf32_Ehdr	* ehdr;
	Elf32_Phdr	* ptab;
	Elf32_Dyn	* dyn;
	struct r_so_resolv	* res;
};

static int
do_reloc(unsigned int *op, unsigned long base, Elf32_Rel *r, Elf32_Sym *sym)
{
	int	ret = 0;

#define	Addend	(*op)
#define	Base	(base)
#define	Place	(r->r_offset)
#define	Sym	(sym->st_value)

	switch (ELF32_R_TYPE(r->r_info)) {
	case R_386_NONE:
		break;
	case R_386_32:
		*op = Sym + Addend;
		break;
	case R_386_PC32:
		*op = Sym + Addend - Place;
		break;
	case R_386_RELATIVE:
		*op = Addend + Base;
		break;
	default:
		/* all other relocation type are unsupported */
		ret = -1;
		break;
	}

#undef	Addend
#undef	Base
#undef	Place
#undef	Sym

	return (ret);
}

static int
relocate_scn(u_long base, Elf32_Ehdr *e, Elf32_Shdr *sh_tab, Elf32_Shdr *rel_sh)
{
	Elf32_Shdr	* sym_sh, * str_sh;
	Elf32_Sym	* sym_tab;
	Elf32_Rel	* rel_tab;
	char	* str_tab;
	int	  i;


	sym_sh = &sh_tab[ rel_sh->sh_link ];	/* relocations linked to syms */
	str_sh = &sh_tab[ sym_sh->sh_link ];	/* syms linked to strings */

#define	get_tab(elf, scn)	(((char*)(elf)) + (scn)->sh_offset)

	sym_tab = (Elf32_Sym *) get_tab(e, sym_sh);
	str_tab = (char *)      get_tab(e, str_sh);
	rel_tab = (Elf32_Rel *) get_tab(e, rel_sh);

#undef get_tab

	for (i = 0; i < rel_sh->sh_size / sizeof(Elf32_Rel); i++) {
		unsigned int	* op;
		Elf32_Rel	* r;
		Elf32_Sym	* sym;
		char		* name;

		r = &rel_tab[i];
		sym = &sym_tab[ELF32_R_SYM(r->r_info)];
		name = &str_tab[sym->st_name];
		op = (unsigned int *) ((char*) e + r->r_offset);

		if (do_reloc(op, base, r, sym))
			return (-1);
	}
	return (0);
}

static int
relocate(mbuf_t *bp, unsigned long base)
{
	Elf32_Ehdr	* e;
	Elf32_Shdr	* sh, * shtab;
	int	i;

	e = (Elf32_Ehdr *) bp->buf;
	shtab = (Elf32_Shdr *) ((char *)bp->buf + e->e_shoff);

	for (i = 0, sh = shtab; i < e->e_shnum; i++, sh++)
		if (sh->sh_type == SHT_REL)
			if (relocate_scn(base, e, shtab, sh))
				return (-1);

	return (0);
}

/*
 * calculate how much space we need, allocate it
 * based on allocation address, relocate local copy of libulexec
 * copy libulexec over
 * set memory permissions
 */
static void *
load_so(rgp_t *rp, mbuf_t *bp)
{
	Elf32_Ehdr	* e;
	Elf32_Phdr	* p, * pend;
	void	* addr;

	/*
	** Allocate space in the remote process
	*/
	addr = rgp_mmap(rp,0,bp->size, PROT_NONE, MAP_PRIVATE|MAP_ANON, -1, 0);
	if (addr == MAP_FAILED) {
		/* XXX error out. */
		return (NULL);
	}

	if (relocate(bp, (unsigned long)addr)) {
		/* clean up, like good little boys and girls */
		/* rgp_munmap(rp, addr, bp->size); *//* unimplemented */
		return (NULL);
	}

	/* copy the code over there.. */
	rgp_copy_to(rp, addr, bp->buf, bp->size);

	/* set permissions here */
	e = (Elf32_Ehdr *) bp->buf;
	p = (Elf32_Phdr *) (((char *)bp->buf) + e->e_phoff);
	pend = &p[e->e_phnum];

	for (; p < pend; p++) {
		void	* start;
		size_t	  len;
		int	  flags;


		if (p->p_type != PT_LOAD)
			continue;

		start = (char *)addr + (p->p_vaddr & ~(p->p_align - 1));
		len = ALIGN(p->p_memsz, p->p_align);

		flags = 0;
		if (p->p_flags & PF_R)
			flags |= PROT_READ;
		if (p->p_flags & PF_W)
			flags |= PROT_WRITE;
		if (p->p_flags & PF_X)
			flags |= PROT_EXEC;

		rgp_mprotect(rp, start, len, flags);
	}
	return addr;
}

static int
load_resolv(r_so_t *rso)
{
	struct r_so_resolv	* res;
	Elf32_Dyn	* dyn;

	if ((res = calloc(1, sizeof(*res))) == NULL) 
		return -1;

	for (dyn = rso->dyn; dyn->d_tag; dyn++) {
		switch (dyn->d_tag) {
		case DT_STRTAB:
			res->strtab = (char *)rso->bp->buf + dyn->d_un.d_ptr;
			break;
		case DT_SYMTAB:
			res->symtab = (Elf32_Sym *)((char *)rso->bp->buf +
					dyn->d_un.d_ptr);
			break;
		case DT_HASH:
			{
				Elf32_Word	* p;

				p = (Elf32_Word *)((char *)rso->bp->buf +
						dyn->d_un.d_ptr);
				res->nbuckets = *p++;
				res->nchains = *p++;
				res->hash = p;
				res->chain = &res->hash[ res->nbuckets ];
			}
			break;
		default:
			break;
		}
	}

	if (!res->strtab || !res->symtab || !res->hash) {
		free(res);
		return (-1);
	}

	rso->res = res;
	return (0);
}

static unsigned long
elf_hash(const unsigned char *name)
{
	unsigned long	h = 0, g;

	while (*name) {
		h = (h << 4) + *name++;

		if ((g = h & 0xf0000000))
		    h ^= g >> 24;
		h &= ~g;
	}
	return h;
}

r_so_t *
r_so_open(const char *elf_buf)
{
	r_so_t	* rso;
	Elf32_Phdr	* p;

	if ((rso = calloc(1, sizeof(r_so_t))) == NULL)
		return NULL;

	if ((rso->bp = ebuf_load(elf_buf)) == NULL) {
		free(rso);
		return NULL;
	}

	rso->ehdr = (Elf32_Ehdr *)rso->bp->buf;
	rso->ptab = (Elf32_Phdr *)((char *)rso->bp->buf + rso->ehdr->e_phoff);

	for (p = rso->ptab; p < &rso->ptab[rso->ehdr->e_phnum]; p++)
		if (p->p_type == PT_DYNAMIC)
			rso->dyn = (Elf32_Dyn *)
				((char *)rso->bp->buf + p->p_vaddr);

	return rso;
}

void
r_so_close(r_so_t *rso)
{
	if (!rso)
		return;
	if (rso->bp)
		ebuf_unload(rso->bp);

	memset(rso, 0x00, sizeof(*rso));
	free(rso);
}

int
r_so_load(r_so_t *rso, rgp_t *rp)
{
	if (!rso || !rso->bp)
		return (-1);

	rso->base = load_so(rp, rso->bp);

	return rso->base ? 0 : -1;
}

/* should be an unload, where we just reload the ebuf */

void *
r_so_get_sym(r_so_t *rso, char *name)
{
	unsigned long	hn, ndx;

	if (!rso || !name || !rso->base)
		return NULL;

	if (!rso->res)
		if (load_resolv(rso))
			return NULL;

	hn = elf_hash((unsigned char *)name) % rso->res->nbuckets;

#if 0
	for (ndx = hn; ndx; ndx = rso->res->chain[ ndx ]) {
		Elf32_Sym	* sym;
		char	* symname;

		sym = rso->res->symtab + ndx;
		symname = rso->res->strtab + sym->st_name;

		if (STRCMP(name, ==, symname))
			return (void *)((char *)rso->base + sym->st_value);
	}
#endif
#if 1
	{
		Elf32_Sym	* sym;
		
		for (ndx = 0; ndx < rso->res->nchains; ndx++) {
			char	* symname;

			sym = &rso->res->symtab[ ndx ];
			symname = rso->res->strtab + sym->st_name;

			if (STRCMP(name, ==, symname))
				return (void*)((char*)rso->base+sym->st_value);
		}
	}
#endif

	return NULL;
}

void *
r_so_get_base(r_so_t *rso)
{
	return rso ? rso->base : NULL;
}

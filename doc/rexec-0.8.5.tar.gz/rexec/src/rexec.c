#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/mman.h>

#include <elf.h>

#include "alist.h"
#include "mbuf.h"
#include "relso.h"
#include "rexec.h"

#include <gdbrpc.h>
#include "libulexec.h"

#define	ALIGN(k, v)	(((k)+((v)-1))&~((v)-1))

extern char **environ;
extern void * load_so(rgp_t *rp, const char *fname);
static int rexec_common(rgp_t *rp, mbuf_t *elf_bp, alist_t *args);
static long fix_stack(rgp_t *rp, long stack_top, long elf_buf, alist_t *argv);


static alist_t *
pptoalist(char **app)
{
	alist_t	* ep;

	if ((ep = alist_new()) == NULL)
		return NULL;

	for (; app && *app; app++)
		if (alist_add(ep, *app)) {
			alist_free(ep);
			return NULL;
		}

	return ep;
}

int
rx_execle(int fd, char *arg0, ...)
{
	alist_t	* args;
	mbuf_t	* bp;
	rgp_t	* rp;
	va_list	  ap;
	char	* arg;
	int	  retval;



	if ((args = alist_new()) == NULL)
		return (-1);

	va_start(ap, arg0);
	for (arg = arg0; arg; arg = va_arg(ap, char *))
		if (alist_add(args, arg))
			return (-1);

	if ((rp = rgp_init(fd)) == NULL) {
		alist_free(args);
		return (-1);
	}

	if ((bp = fbuf_load(arg0)) == NULL) {
		alist_free(args);
		rgp_fini(rp);
		return (-1);
	}

	retval = rexec_common(rp, bp, args);

	fbuf_unload(bp);
	alist_free(args);
	rgp_fini(rp);

	return (retval);
}

int
rx_execl(int fd, char *path, char *arg, ...)
{
	alist_t	* args;
	mbuf_t	* bp;
	rgp_t	* rp;
	va_list	  ap;
	char	* str;
	int	  retval;


	va_start(ap, arg);
	for (str = path; str; str = va_arg(ap, char *)) {
		if (alist_add(args, str))
			return (-1);
	}
	va_end(ap);

	if ((rp = rgp_init(fd)) == NULL) {
		alist_free(args);
		return (-1);
	}

	if ((bp = fbuf_load(path)) == NULL) {
		alist_free(args);
		rgp_fini(rp);
		return (-1);
	}


	retval = rexec_common(rp, bp, args);

	fbuf_unload(bp);
	alist_free(args);
	rgp_fini(rp);

	return (retval);
}

int
rx_execve(int fd, char *fname, char *argv[], char *envp[])
{
	alist_t	* args;
	mbuf_t	* bp;
	rgp_t	* rp;
	int	  retval;

	
	if ((bp = fbuf_load(fname)) == NULL) 
		return (-1);

	if ((args = pptoalist(argv)) == NULL)
		return (-1);

	if ((rp = rgp_init(fd)) == NULL) {
		alist_free(args);
		return (-1);
	}

	retval = rexec_common(rp, bp, args);

	fbuf_unload(bp);
	alist_free(args);
	rgp_fini(rp);

	return (retval);
}

/*
 *
 */
static void *
load_buf(rgp_t *rp, void *buf, size_t len)
{
	void	* addr;

	addr = rgp_mmap(rp, 0, len, PROT_READ|PROT_EXEC,
					MAP_ANONYMOUS|MAP_PRIVATE, -1, 0);
	if (addr == MAP_FAILED)
		return NULL;

	rgp_copy_to(rp, addr, buf, len);

	return addr;
}

static int
rexec_common(rgp_t *rp, mbuf_t *elf_bp, alist_t *argv)
{
	void	* elf_buf, * ul_exec;
	long	  stack_bottom;
	r_so_t	* ul_rso;


	/*
	** upload ELF_buf
	*/
	elf_buf = load_buf(rp, elf_bp->buf, elf_bp->size);
	if (elf_buf == NULL)
		return (-1);

	/*
	** load and fix up the libulexec shared object
	*/
	if ((ul_rso = r_so_open(libulexec)) == NULL)
		return (-1);

	if (r_so_load(ul_rso, rp))
		return (-1);

	/*
	** get stack base
	** set up stack
	*/

	/* 2.6 has some annoying shit... gotta sort it properly */
	stack_bottom = fix_stack(rp, 0xc0000000, (long)elf_buf, argv);

	rgp_set_esp(rp, stack_bottom);

	/*
	** set up transfer of control 
	*/
	if ((ul_exec = r_so_get_sym(ul_rso, "ul_exec")) == NULL)
		return (-1);

	rgp_set_eip(rp, ul_exec);

	/*
	** ... and we're done.
	*/

	r_so_close(ul_rso);

	return (0);
}

static long
fix_stack(rgp_t *rp, long stack_top, long elf_buf, alist_t *argv)
{
	int	argsize, i;
	long	esp, addr, ptr, arg_strings;

	argsize = 4; /* fake return address */
	argsize += 4; /* ELF_buf */
	argsize += 4; /* argc*/
	argsize += 4; /* &argv[][] */
	argsize += alist_get_cnt(argv) * sizeof(char *); /* argv */
	argsize += 4; /* NULL */

	/* argv strings */
	if (alist_get_cnt(argv))
		for (i = 0; i < alist_get_cnt(argv); i++)
			argsize += strlen(alist_get_num(argv, i)) + 1;

	/* strings [ NULL ] */
	argsize += 4;

	/* just align on a four byte boundary */
	argsize = (argsize + 3) & ~3;

	esp = ptr = stack_top - argsize;

	rgp_set_range(rp, (void *)ptr, 0, argsize);

	/* set fake return address */
	rgp_set_addr32(rp, (void *)ptr, 0xdeadbeef);
	ptr += 4;

	/* set ELF_buf */
	rgp_set_addr32(rp, (void *)ptr, elf_buf);
	ptr += 4;
	
	/* set argc */
	rgp_set_addr32(rp, (void *)ptr, alist_get_cnt(argv));
	ptr += 4;

	/* ptr = &argv[0] */
	rgp_set_addr32(rp, (void *)ptr, ptr + 4);
	ptr += 4;

	arg_strings = ptr + (((alist_get_cnt(argv) + 1) * sizeof(char *))) +
			sizeof(char *);

	for (i = 0, addr = arg_strings; i < alist_get_cnt(argv); i++) {
		size_t len = strlen(alist_get_num(argv, i)) + 1;

		/* argv[i] = &str */
		rgp_set_addr32(rp, (void *)ptr, addr);

		/* strcpy(&str, string) */
		rgp_copy_to(rp, (void *)addr, alist_get_num(argv, i), len);

		addr += len;
		ptr += sizeof(char *);
	}

	return esp;
}

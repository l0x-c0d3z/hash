#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "alist.h"


struct arg_list {
	char	**argv;
	int	  argc;
	int	  narg;
	size_t	  length;
};

alist_t *
alist_new(void)
{
	return calloc(1, sizeof(struct arg_list));
}

int
alist_add(alist_t *alist, char *arg)
{
	char	* ptr;


	if (!alist || !arg)
		return (-1);

	if (alist->argc >= alist->narg) {
		alist->narg += 5;

		ptr = realloc(alist->argv, alist->narg * sizeof(char *));

		if (!ptr) {
			alist->narg -= 5;
			return (-1);
		}

		alist->argv = (char **)ptr;
	}

	if ((ptr = strdup(arg)) == NULL)
		return (-1);

	alist->argv[alist->argc++] = ptr;
	alist->length += strlen(ptr);

	return (0);
}

void
alist_free(alist_t *alist)
{
	int	i;

	if (alist) {
		for (i = 0; i < alist->argc; i++)
			free(alist->argv[i]);
		free(alist->argv);
		free(alist);
	}
	return;
}

void
alist_dump(FILE * out, alist_t *al)
{
	int	  i;

	for (i = 0; i < al->argc; i++)
		fprintf(out, "[%d]-> %s\n", i, al->argv[i]);
	return;
}

int
alist_get_cnt(alist_t *al)
{
	return al ? al->argc : -1;
}

char *
alist_get_num(alist_t *al, int num)
{
	/* XXX this fails for alist_r's with argc == 0 */
	if (al)
		if (num >= 0  && num <= al->argc)
			return al->argv[num];
	return NULL;
}

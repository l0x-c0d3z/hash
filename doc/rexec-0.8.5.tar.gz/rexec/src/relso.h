#ifndef REMOTE_SHARED_OBJECT_HEADER_
#define REMOTE_SHARED_OBJECT_HEADER_	1

#include <elf.h>
#include <mbuf.h>
#include <gdbrpc.h>

typedef struct r_so r_so_t;

r_so_t * r_so_open(const char *fname);
void * r_so_get_base(r_so_t *rso);
void * r_so_get_sym(r_so_t *rso, char *name);
int r_so_load(r_so_t *rso, rgp_t *rp);
void r_so_close(r_so_t *rso);

#endif /* REMOTE_SHARED_OBJECT_HEADER_ */

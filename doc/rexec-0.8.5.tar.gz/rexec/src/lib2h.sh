#!/bin/sh

name=$1
file=$2

echo "#ifndef _${name}_H_"
echo "#define _${name}_H_ 1"
echo ""

echo "static const unsigned char * $name = "

od -tx1 -An -v $file | while read line
do
	echo -e -n "\t\""
	for byte in $line
	do
		echo -n "\\x$byte"
	done

	echo "\""
done

echo ";"
echo "#endif /* _${name}_H_ */"

#ifndef ALIST_H_
#define ALIST_H_	1

typedef struct arg_list alist_t;

alist_t * alist_new(void);
int alist_add(alist_t *alist, char *arg);
void alist_free(alist_t *alist);
void alist_dump(FILE * out, alist_t *al);
int alist_get_cnt(alist_t *al);
char * alist_get_num(alist_t *al, int num);

#endif /* ALIST_H_ */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <elf.h>

#include "mbuf.h"

#define	ALIGN(k, v)	(((k)+((v)-1))&~((v)-1))

static mbuf_t *
mbuf_load(int fd, size_t size)
{
	mbuf_t	* bp;
	int	  flags;
	int	  prot;


	if ((bp = calloc(1, sizeof(*bp))) == NULL)
		return NULL;

	bp->size = size;
	bp->fd = fd;

	prot = PROT_READ|PROT_WRITE;
	flags = MAP_PRIVATE;

	flags |= bp->fd < 0 ? MAP_ANONYMOUS : 0;

	bp->buf = mmap(NULL, bp->size, prot, flags, bp->fd, 0);
	if (bp->buf == MAP_FAILED) {
		close(bp->fd);
		free(bp);
		return NULL;
	}

	return bp;
}

static void
mbuf_unload(mbuf_t *bp)
{
	if (!bp)
		return;

	close(bp->fd);
	munmap(bp->buf, bp->size);
	free(bp);

	return;
}

void
fbuf_unload(mbuf_t *bp)
{
	mbuf_unload(bp);
}

void 
ebuf_unload(mbuf_t *bp)
{
	mbuf_unload(bp);
}

mbuf_t *
fbuf_load(const char *fname)
{
	struct stat	st;
	mbuf_t	* bp;
	int	  fd;
	

	if ((fd = open(fname, O_RDONLY)) < 0)
		return NULL;

	if (fstat(fd, &st)) {
		close(fd);
		return NULL;
	}

	if ((bp = mbuf_load(fd, st.st_size)) == NULL) {
		close(fd);
		return NULL;
	}

	return bp;
}

mbuf_t *
ebuf_load(const char *elf)
{
	Elf32_Ehdr	* eh;
	Elf32_Phdr	* p, * ptab;
	mbuf_t	* bp;
	size_t	  len;


	eh = (Elf32_Ehdr *) elf;
	ptab = (Elf32_Phdr *) (elf + eh->e_phoff);

	len = 0;
	for (p = ptab; p < &ptab[ eh->e_phnum ]; p++) {
		if (p->p_type != PT_LOAD)
			continue;

		len += ALIGN(p->p_memsz, p->p_align);
	}

	if ((bp = mbuf_load(-1, len)) == NULL)
		return NULL;

	for (p = ptab; p < &ptab[ eh->e_phnum ]; p++) {
		void	* load_addr;
		off_t	  offset;

		if (p->p_type != PT_LOAD)
			continue;

		load_addr = (char *)bp->buf + (p->p_vaddr & ~(p->p_align - 1));
		len = ALIGN(p->p_memsz, p->p_align);
		offset = p->p_offset & ~(p->p_align - 1);

		memcpy(load_addr, elf + offset, len);
	}

	return (bp);
}

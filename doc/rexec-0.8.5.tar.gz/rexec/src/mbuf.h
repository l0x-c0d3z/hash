#ifndef MBUF_H_
#define MBUF_H_	1

typedef struct mbuf {
	void	* buf;
	size_t	  size;
	int	  fd;
} mbuf_t;

mbuf_t * ebuf_load(const char *fname);
void ebuf_unload(mbuf_t *bp);

mbuf_t *fbuf_load(const char *fname);
void fbuf_unload(mbuf_t *bp);
#endif /* MBUF_H_ */

#ifndef REXEC_H_
#define REXEC_H_ 1


extern char	* rx_ul_exec_path;

#define	rx_set_ul_exec(str)	(rx_ul_exec_path = (str))
#define	rx_get_ul_exec()	(rx_ul_exec_path)
#define	DEFAULT_UL_EXEC_PATH	"ul_exec/src/libulexec.so"

/* functions prototypes */
int rx_execle(int fd, char *arg0, ...);
int rx_execl(int fd, char *path, char *arg, ...);
int rx_execve(int fd, char *fname, char *argv[], char *envp[]);

#endif /* REXEC_H_ */

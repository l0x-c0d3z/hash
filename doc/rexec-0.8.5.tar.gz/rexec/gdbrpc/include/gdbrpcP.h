#ifndef GDB_RPC_PRIV_H_
#define GDB_RPC_PRIV_H_	1

#include <sys/types.h>
#include <gdbrpc.h>

struct gdb_rpc {
	int	fd;
	int	open;
};

#define	IS_VALID_RGP(rgp)	((rgp) && (rgp)->open)

ssize_t rgp_vsend_cmd(rgp_t *rp, const char *fmt, va_list ap);
ssize_t rgp_send_cmd(rgp_t *rp, const char *fmt, ...);
int rgp_exec_cmd(rgp_t *rp, const char *fmt, ...);
char * rgp_next_prompt(rgp_t *rp);
int rgp_get_result(char *buffer, char **val);

#endif /* GDB_RPC_PRIV_H_ */

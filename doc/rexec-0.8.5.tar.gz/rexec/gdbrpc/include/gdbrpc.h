#ifndef GDB_RPC_H_
#define GDB_RPC_H_	1

#include <sys/types.h>

typedef struct gdb_rpc rgp_t;

/*
 * init / fini crap.
 */
rgp_t * rgp_init(int fd);
void rgp_fini(rgp_t *rp);

/*
 * memory manipulation cmds
 */
void * rgp_mmap(rgp_t *rp, void *start, size_t length, int prot, int flags,
		int fd, off_t offset);
int rgp_brk(rgp_t *rp, void * end_data_segment);
int rgp_mprotect(rgp_t *rp, const void *addr, size_t len, int prot);
int rgp_mlock(rgp_t *rp, const void *addr, size_t len);

/*
 * memory content manipulation functions
 */
void rgp_copy_to(rgp_t *rp, void *remote, void *local, size_t n);
void rgp_copy_from(rgp_t *rp, void *local, void *remote, size_t n);
void rgp_set_range(rgp_t *rp, void *remote, unsigned char c, size_t n);

/*
 * set/get memory values
 */
void rgp_set_addr8(rgp_t *rp, void *addr, unsigned char val);
void rgp_set_addr16(rgp_t *rp, void *addr, unsigned short val);
void rgp_set_addr32(rgp_t *rp, void *addr, unsigned int val);

unsigned char rgp_get_addr8(rgp_t *rp, void *addr);
unsigned short rgp_get_addr16(rgp_t *rp, void *addr);
unsigned int rgp_get_addr32(rgp_t *rp, void *addr);


/*
 * gdb and host-process configuration stuff
 */

extern char	* rgp_gdb;
extern char	* rgp_gdb_args;
extern char	* rgp_gdb_prompt;
extern char	* rgp_host;
extern char	* rgp_host_args;

#define rgp_get_gdb()		(rgp_gdb)
#define	rgp_get_gdb_args()	(rgp_gdb_args)
#define	rgp_get_gdb_prompt()	(rgp_gdb_prompt)
#define	rgp_get_host()		(rgp_host)
#define	rgp_get_host_args()	(rgp_host_args)

#define	rgp_set_gdb(str)	(rgp_gdb = (str))
#define	rgp_set_gdb_args(str)	(rgp_gdb_args = (str))
#define	rgp_set_gdb_prompt(str)	(rgp_gdb_prompt = (str))
#define	rgp_set_host(str)	(rgp_host = (str))
#define	rgp_set_host_args(str)	(rgp_host_args = (str))

/*
 * register manipulation cmds
 */
typedef enum {
	EAX = 0,
	EBX,
	ECX,
	EDX,
	EIP,
	EBP,
	ESP	/* must be last */
} rgp_reg;

void rgp_set_reg(rgp_t *rp, rgp_reg reg, unsigned int val);
unsigned int rgp_get_reg(rgp_t *rp, rgp_reg reg);

#define	rgp_set_eax(rp, val) rgp_set_reg(rp, EAX, (unsigned int)(val))
#define	rgp_set_ebx(rp, val) rgp_set_reg(rp, EBX, (unsigned int)(val))
#define	rgp_set_ecx(rp, val) rgp_set_reg(rp, ECX, (unsigned int)(val))
#define	rgp_set_edx(rp, val) rgp_set_reg(rp, EDX, (unsigned int)(val))
#define	rgp_set_eip(rp, val) rgp_set_reg(rp, EIP, (unsigned int)(val))
#define	rgp_set_ebp(rp, val) rgp_set_reg(rp, EBP, (unsigned int)(val))
#define	rgp_set_esp(rp, val) rgp_set_reg(rp, ESP, (unsigned int)(val))

#define	rgp_get_eax(rp) rgp_set_reg(rp, EAX)
#define	rgp_get_ebx(rp) rgp_set_reg(rp, EBX)
#define	rgp_get_ecx(rp) rgp_set_reg(rp, ECX)
#define	rgp_get_edx(rp) rgp_set_reg(rp, EDX)
#define	rgp_get_eip(rp) rgp_set_reg(rp, EIP)
#define	rgp_get_ebp(rp) rgp_set_reg(rp, EBP)
#define	rgp_get_esp(rp) rgp_set_reg(rp, ESP)

/*
 * callback for informational reports
 */

/* void callback(void *to, void *from, size_t total, size_t rem) */
extern void (*rgp_copy_to_callback)();
extern void (*rgp_copy_from_callback)();

#define	rgp_get_copy_to_callback()		(rgp_copy_to_callback)
#define	rgp_get_copy_from_callback()		(rgp_copy_from_callback)
#define	rgp_set_copy_to_callback(clbk)		(rgp_copy_to_callback=(clbk))
#define	rgp_set_copy_from_callback(clbk) 	(rgp_copy_from_callback=(clbk))

#endif /* GDB_RPC_H_ */

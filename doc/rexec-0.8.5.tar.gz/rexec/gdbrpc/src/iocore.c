#include <alloca.h>
#include <ctype.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#include <gdbrpcP.h>

void (*rgp_copy_to_callback)();
void (*rgp_copy_from_callback)();

/****************************************************************************/
/*                     address manipulation                                 */
/****************************************************************************/
void
rgp_set_addr8(rgp_t *rp, void *addr, unsigned char val)
{
	if (!IS_VALID_RGP(rp))
		return;
	rgp_exec_cmd(rp, "set {char} 0x%x = 0x%0.02x", addr, val);
}

void
rgp_set_addr16(rgp_t *rp, void *addr, unsigned short val)
{
	if (!IS_VALID_RGP(rp))
		return;
	rgp_exec_cmd(rp, "set {short} 0x%x = 0x%0.04x", addr, val);
}

void
rgp_set_addr32(rgp_t *rp, void *addr, unsigned int val)
{
	if (!IS_VALID_RGP(rp))
		return;
	rgp_exec_cmd(rp, "set {int} 0x%x = 0x%0.08x", addr, val);
}

unsigned char
rgp_get_addr8(rgp_t *rp, void *addr)
{
	char	* buf;

	if (!IS_VALID_RGP(rp))
		return (-1);

	rgp_send_cmd(rp, "p/x *(unsigned char *)0x%x", addr);
	rgp_get_result(rgp_next_prompt(rp), &buf);

	return (unsigned char) strtoul(buf, (char **)0, 0);
}	

unsigned short
rgp_get_addr16(rgp_t *rp, void *addr)
{
	char	* buf;


	if (!IS_VALID_RGP(rp))
		return (-1);

	rgp_send_cmd(rp, "p/x *(unsigned short *)0x%x", addr);
	rgp_get_result(rgp_next_prompt(rp), &buf);

	return (unsigned short) strtoul(buf, (char **)0, 0);
}

unsigned int
rgp_get_addr32(rgp_t *rp, void *addr)
{
	char	* buf;


	if (!IS_VALID_RGP(rp))
		return (-1);

	rgp_send_cmd(rp, "p/x *(unsigned int *)0x%x", addr);
	rgp_get_result(rgp_next_prompt(rp),  &buf);

	return (unsigned int) strtoul(buf, (char **)0, 0);
}

/****************************************************************************/
/*                     buffer manipulation                                  */
/****************************************************************************/
void
rgp_copy_to(rgp_t *rp, void *remote, void *local, size_t n)
{
	unsigned char	* ptr = (unsigned char *) local;
	void	(*callback)(void *to, void *from, size_t total, size_t remain);
	long		  addr = (long) remote;
	size_t		  size = n;

	if (!IS_VALID_RGP(rp))
		return;

	callback = rgp_get_copy_to_callback();
	
	while (n > 0) {

		if (callback)
			callback(remote, local, size, size - n);

		switch (n % sizeof(int)) {
		case 3: /* FALL THRU */
		case 2:
			rgp_set_addr16(rp, (void *)addr,
					*((unsigned short *)ptr));

			addr += sizeof(short);
			ptr += sizeof(short);
			n -= sizeof(short);
			break;
		case 1:
			rgp_set_addr8(rp, (void *)addr, *ptr);

			addr++;
			ptr++;
			n--;
			break;
		case 0:
		default:
			rgp_set_addr32(rp, (void *)addr,
					*((unsigned int *)ptr));

			addr += sizeof(int);
			ptr += sizeof(int);
			n -= sizeof(int);
			break;
		}
	}
}

void
rgp_copy_from(rgp_t *rp, void *local, void *remote, size_t n)
{
	unsigned char	* ptr = (unsigned char *) local;
	void	(*callback)(void *to, void *from, size_t total, size_t remain);
	long		  addr = (long) remote;
	size_t		  size = n;


	if (!IS_VALID_RGP(rp))
		return;

	callback = rgp_get_copy_from_callback();

	while (n > 0) {
		unsigned int	* ip;
		unsigned short	* sp;

		if (callback)
			callback(remote, local, size, size - n);

		switch (n % sizeof(int)) {
		case 3: /* FALL THRU */
		case 2:
			sp = (unsigned short *) ptr;
			*sp = rgp_get_addr16(rp, (void *)addr);

			ptr += sizeof(short);
			addr += sizeof(short);
			n -= sizeof(short);
			break;
		case 1:
			*ptr = rgp_get_addr8(rp, (void *)addr);

			ptr++;
			addr++;
			n--;
			break;
		case 0: /* FALL THRU */
		default:
			ip = (unsigned int *) ptr;
			*ip = rgp_get_addr32(rp, (void *)addr);

			ptr += sizeof(int);
			addr += sizeof(int);
			n -= sizeof(int);
			break;
		}
	}
}

void
rgp_set_range(rgp_t *rp, void *remote, unsigned char c, size_t n)
{
	char	* ptr;

	if (!IS_VALID_RGP(rp))
		return;

	ptr = alloca(n);
	memset(ptr, c, n);

	rgp_copy_to(rp, remote, ptr, n);
}

/****************************************************************************/
/*                     register manipulation                                */
/****************************************************************************/
static char **registers;

static int
init_regs(void)
{
	if ((registers = malloc(ESP * sizeof(char *))) == NULL)
		return (-1);

	registers[EAX] = "eax";
	registers[EBX] = "ebx";
	registers[ECX] = "ecx";
	registers[EDX] = "edx";
	registers[EIP] = "eip";
	registers[EBP] = "ebp";
	registers[ESP] = "esp";

	return (0);
}

void
rgp_set_reg(rgp_t *rp, rgp_reg reg, unsigned int val)
{
	if (!IS_VALID_RGP(rp))
		return;

	if (!registers)
		if (init_regs())
			return; /* all about the error reporting */
	rgp_exec_cmd(rp, "set $%s = 0x%x", registers[reg], val);
}

unsigned int
rgp_get_reg(rgp_t *rp, rgp_reg reg)
{
	char	* buf;

	if (!IS_VALID_RGP(rp))
		return (0);

	if (!registers)
		if (init_regs())
			return (0);

	rgp_send_cmd(rp, "p/x $%s", registers[reg]);
	rgp_get_result(rgp_next_prompt(rp), &buf);

	return strtoul(buf, (char **)0, 0);
}

#include <alloca.h>
#include <ctype.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/poll.h>
#include <sys/types.h>
#include <unistd.h>

#include <gdbrpcP.h>

#define DEFAULT_GDB_PROMPT  "(gdb) "

char	* rgp_gdb = "gdb";
char	* rgp_gdb_args = "-n -q";
char	* rgp_gdb_prompt = DEFAULT_GDB_PROMPT;
char	* rgp_host = "ps";
char	* rgp_host_args = "-e";

rgp_t *
rgp_init(int fd)
{
	rgp_t   * rp;
	char	* prompt;

	if ((rp = malloc(sizeof(*rp))) == NULL)
		return NULL;
	rp->fd = fd;
	rp->open = 1;

	/***************************************************************/
	prompt = rgp_get_gdb_prompt();
	rgp_set_gdb_prompt(DEFAULT_GDB_PROMPT);

	rgp_exec_cmd(rp, "%s %s %s", rgp_get_gdb(), rgp_get_gdb_args(),
			rgp_get_host()); 
	rgp_set_gdb_prompt(prompt);

	rgp_exec_cmd(rp, "set prompt %s", rgp_get_gdb_prompt());
	rgp_exec_cmd(rp, "tbreak __libc_start_main");
	rgp_exec_cmd(rp, "run %s", rgp_get_host_args());
	(void) rgp_next_prompt(rp);
	/**************************************************************/

	return (rp);
}

void
rgp_fini(rgp_t *rp)
{
	if (!IS_VALID_RGP(rp))
		return;
	rgp_send_cmd(rp, "detach");
	rgp_send_cmd(rp, "quit");

	free(rp);
        return;
}

/*
 * basic comms commands
 */
ssize_t
rgp_vsend_cmd(rgp_t *rp, const char *fmt, va_list ap)
{
	char	* buf,
		  tmp[1];
	int	  n;

	if (!IS_VALID_RGP(rp))
		return (-1);

	if ((n = vsnprintf(tmp, sizeof(tmp), fmt, ap)) < 0)
		return (-1);

	if ((buf = alloca(n + 3)) == NULL)
		return (-1);

	if ((n = vsnprintf(buf, n + 1, fmt, ap)) < 0)
		return (-1);
	buf[n++] = '\r';
	buf[n] = 0;

	return write(rp->fd, buf, n);
}

ssize_t
rgp_send_cmd(rgp_t *rp, const char *fmt, ...)
{
	va_list	ap;
	ssize_t	nr;

	va_start(ap, fmt);
	nr = rgp_vsend_cmd(rp, fmt, ap);
	va_end(ap);

	return nr;
}

int
rgp_exec_cmd(rgp_t *rp, const char *fmt, ...)
{
	va_list	ap;
	ssize_t	nr;

	va_start(ap, fmt);
	nr = rgp_vsend_cmd(rp, fmt, ap);
	va_end(ap);

	if (nr < 0)
		return (nr);

	return (rgp_next_prompt(rp) == NULL ? -1 : 0);
}

int
rgp_get_result(char *buffer, char **val)
{
	char    * ptr;


	if (!buffer || !val)
		return (-1);

	if ((ptr = strchr(buffer, '=')) == NULL)
		return (-1);

	while (isspace(*ptr++))
		;
	
	*val = ++ptr;

	return (0);
}


static char *
next_prompt(int fd, char *prompt)
{
	static char	* buf;
	static size_t	  bsize;
	struct pollfd 	ufd = { 0, 0, 0};
	size_t	off;

	/* should really do one byte reads, with tiny timeouts */
#define	RD_SIZE	128

	if (buf)
		memset(buf, 0, bsize);

	off = 0;

	while (1) {
		ssize_t	nr;
		int	n, timeout;

		timeout = 10 * 1000;

		ufd.fd = fd;
		ufd.events |= POLLIN;

		if ((n = poll(&ufd, 1, timeout)) < 1)
			return NULL;

		if (off + RD_SIZE + 1 >= bsize) {
			char	* nbuf;
			size_t	  nsize;

			nsize = bsize + RD_SIZE + 2;

			if ((nbuf = realloc(buf, nsize)) == NULL)
				return NULL;
			memset(nbuf + off, 0, nsize - off);

			bsize = nsize;
			buf = nbuf;
		}

		if ((nr = read(fd, buf + off, RD_SIZE)) < 0)
			return NULL;
		off += nr;

		if (strstr(buf, prompt))
			return buf;
	}
}

#if 0
#include <expect.h>
static char *
next_prompt(int fd, char *prompt)
{
	if ((exp_expectl(fd, exp_glob, prompt, 0, exp_end)))
		return NULL;
	return exp_buffer;
}
#endif

char *
rgp_next_prompt(rgp_t *rp)
{
	if (!IS_VALID_RGP(rp))
		return NULL;

	return next_prompt(rp->fd, rgp_get_gdb_prompt());
}

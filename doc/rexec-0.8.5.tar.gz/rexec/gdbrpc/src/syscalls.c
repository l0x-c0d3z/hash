#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <sys/mman.h>

#include <gdbrpcP.h>

/****************************************************************************/
/*                      syscall implementations                             */
/****************************************************************************/

static long
rgp_syscall(rgp_t *rp, const char *fmt, ...)
{
	va_list	  ap;
	int	  ret;
	char	* buf;

	va_start(ap, fmt);
	ret = rgp_vsend_cmd(rp, fmt, ap);
	va_end(ap);

	if (ret < 0)
		return (ret);

	if (rgp_get_result(rgp_next_prompt(rp), &buf))
		return (-1);

	return (long) strtoul(buf, (char **)0, 0);
}

void *
rgp_mmap(rgp_t *rp, void *start, size_t length, int prot, int flags, int fd,
		off_t offset)
{
	char	* buf;


	if (!IS_VALID_RGP(rp))
		return MAP_FAILED;

	if (rgp_send_cmd(rp, "p/x mmap(0x%x, %u, 0x%x, 0x%x, %d, 0x%x)",
				start, length, prot, flags, fd, offset) < 0)
		return MAP_FAILED;

	if (rgp_get_result(rgp_next_prompt(rp), &buf))
		if (rgp_get_result(rgp_next_prompt(rp), &buf))
			return MAP_FAILED;

	return (void *) strtoul(buf, (char **)0, 16);
}

int
rgp_mprotect(rgp_t *rp, const void *addr, size_t len, int prot)
{
	if (!IS_VALID_RGP(rp))
		return (-1);

	return (int) rgp_syscall(rp, "p/x mprotect(0x%x, 0x%x, 0x%x)",
			addr, len, prot);
}

int
rgp_mlock(rgp_t *rp, const void *addr, size_t len)
{
	if (!IS_VALID_RGP(rp))
		return (-1);

	return (int) rgp_syscall(rp, "p/x mlock(0x%x, 0x%x)",
			addr, len);
}

int
rgp_brk(rgp_t *rp, void *end_data_segment)
{
	if (!IS_VALID_RGP(rp))
		return (-1);

	return (int) rgp_syscall(rp, "p/x brk(0x%x)", end_data_segment);
}

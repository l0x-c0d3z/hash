

/****************************************************************************/
/*                     random shell commands                                */
/****************************************************************************/
char *
rgp_system(rgp_t *rp, char *cmd)
{
	char	* buf;


	if (!IS_VALID_RGP(rp))
		return NULL;

	rgp_send_cmd(rp, "shell %s", cmd);
	rgp_get_result(rgp_next_prompt(rp), &buf);

	/* clean the buf here */

	return (buf);
}

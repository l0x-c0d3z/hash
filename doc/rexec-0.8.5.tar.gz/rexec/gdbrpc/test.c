#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <expect.h>

#include <sys/mman.h>

#include <gdbrpc.h>


#define	MY_CNT	301
#define	MY_SIZE	(MY_CNT * sizeof(int))

static int	Count;

static void
print_stats(void *to, void *from, size_t total, size_t rem)
{
	char	spinner[] = "-\\|/";
	char	backup[] = "\b\b\b\b\b\b\b\b";
	int	percent = 0;
       
	if (rem)
		percent = (rem * 100) / total;

	if (Count)
		printf("%s", backup);

	printf("[%c] %3d%%", spinner[Count % 4], percent);
	fflush(stdout);

	Count++;
}

static void
test_memcpy(rgp_t *rp)
{
	int	i;
	int	* buf;
	char	* rbuf;


	buf = malloc(MY_SIZE);

	for (i = 0; i < MY_CNT; i++)
		buf[i] = i;

	rbuf = rgp_mmap(rp, NULL, MY_SIZE , PROT_READ|PROT_WRITE,
			MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
	if (rbuf == MAP_FAILED)
		return;
	
	printf("Uploading buffer: ");
	rgp_set_copy_to_callback(print_stats);

	rgp_copy_to(rp, rbuf, buf, MY_SIZE);

	printf("\n");

	for (i = 0; i < MY_CNT; i++) {
		unsigned int	val;

		val = rgp_get_addr32(rp, (int *)rbuf + i);
		printf("%d -> %u\n", i, val);
	}

	memset(buf, 0, MY_SIZE);

	Count = 0;
	printf("Downloading buffer: ");
	rgp_set_copy_from_callback(print_stats);
	rgp_copy_from(rp, buf, rbuf, MY_SIZE);

	printf("\n");

	for (i = 0; i < MY_CNT; i++)
		printf("%d = %d\n", i, buf[i]);

	free(buf);
}

static int
do_connect(char *host, char *port)
{
	return exp_spawnl("/usr/bin/nc", "-vv", host, port, NULL);
}

int
main(int argc, char **argv)
{
	rgp_t	* rp;
	int	  sock;


	if (argc < 3) {
		printf("usage: %s <host> <port>\n", argv[0]);
		return (2);
	}

	sock = do_connect(argv[1], argv[2]);
	rp = rgp_init(sock);

	test_memcpy(rp);

	rgp_fini(rp);
	close(sock);

	return (0);
}

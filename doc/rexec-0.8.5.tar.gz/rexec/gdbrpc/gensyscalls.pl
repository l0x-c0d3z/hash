#!/usr/bin/perl
#
#

$file = "./syscalls.conf";
open(CALLS, $file); 
@lines = <CALLS>;
close(CALLS);

foreach $line (@lines)
{
	chomp($line);
	@data = split(",", $line);
	($sys_type, $sys_name) = @data;

	%args = @data;

	# print the function name and args
	printf "%s rgp_%s(rgp_t *rp", $sys_type, $sys_name;

	while (($arg_type, $arg_name) = each(%args))
	{
		printf ", %s %s", $arg_type, $arg_name;
	}
	printf ")\n{\n";

	printf "\tif (!IS_VALID_RGP(rp)) return (-1);\n\n";

	printf "\treturn (%s) rgp_syscall(rp->fd, \"p/x %s(",
		$sys_type, $sys_name;

	%args = @data;

	$first = 1;
	while (($arg_type, $arg_name) = each(%args))
	{
		if (!$first) {
		       	printf ", ";
		} else {
			$first = 0;
		}

		printf "0x%%x";
	}
	printf ")\"";

	%args = @data;
	while (($arg_type, $arg_name) = each(%args))
	{
		printf ", %s", $arg_name;
	}
	printf ");\n}\n\n"

}

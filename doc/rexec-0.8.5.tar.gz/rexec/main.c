#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>
#include <pty.h>

#include "rexec.h"

static unsigned int 
resolve(char *host)
{
	unsigned int	i;
	struct hostent	* he;

	if ((i = inet_addr(host)) == -1) {
		if ((he = gethostbyname(host)) == NULL)
			return (0);
		return (*(unsigned int *)he->h_addr);
	}
	return i;
}

static int
open_socket(char *host, short port)
{
	struct sockaddr_in	sa;
	int	sd;


	sa.sin_family = AF_INET;
	sa.sin_port = htons(port);

	if ((sd = socket(sa.sin_family, SOCK_STREAM, 0)) == -1)
		return (-1);

	if (!(sa.sin_addr.s_addr = resolve(host))) {
		close(sd);
		return (-1);
	}

	if (connect(sd, (struct sockaddr *)&sa, sizeof(struct sockaddr_in))) {
		close(sd);
		return (-1);
	}

	return sd;
}

static void
copy_data(int from, int to)
{
	ssize_t	n;
	char	buf[512];

	if ((n = read(from, buf, sizeof(buf))) < 0)
		return;
	write(to, buf, n);
}

static void
multiplex(int fd)
{
	while (1) {
		fd_set	fds;

		FD_ZERO(&fds);
		FD_SET(STDIN_FILENO, &fds);
		FD_SET(fd, &fds);

		if (select(fd+1, &fds, NULL, NULL, NULL) < 0)
			exit(2);

		if (FD_ISSET(STDIN_FILENO, &fds))
			copy_data(STDIN_FILENO, fd);

		if (FD_ISSET(fd, &fds))
			copy_data(fd, STDIN_FILENO);
	}
}

static int
do_connect(char *host, char *port)
{
	pid_t	child;
	int	master;

	if ((child = forkpty(&master, NULL, NULL, NULL)) < 0) {
		perror("forkpty() failed");
		exit(1);
	}

	if (!child) {
		int	sd;

		if ((sd = open_socket(host, (short)strtol(port, NULL, 0))) <0)
			exit(2);

		multiplex(sd);
	}

	return (master);
}

void dupshell(int fd)
{
	while (1) {
		ssize_t	nr;
		fd_set	fds;
		char	buf[512];

		FD_ZERO(&fds);
		FD_SET(STDIN_FILENO, &fds);
		FD_SET(fd, &fds);
		memset(buf, 0x00, sizeof(buf));

		select(fd + 1, &fds, NULL, NULL, NULL);

		if (FD_ISSET(STDIN_FILENO, &fds)) {
			if ((nr = read(STDIN_FILENO, buf, sizeof(buf))) <0) {
				perror("fucking read.");
				exit(2);
			}
			write(fd, buf, nr);
		}

		if (FD_ISSET(fd, &fds)) {
			if ((nr = read(fd, buf, sizeof(buf))) < 0) {
				perror("fuck read. and fuck you.");
				exit(2);
			}
			write(STDOUT_FILENO, buf, nr);
		}
	}
}

int
main(int argc, char **argv, char **envp)
{
	int	sock, retval;


	if (argc < 3) {
		printf("%s [host] [port] [prog] <args>\n", argv[0]);
		return (2);
	}


	if ((sock = do_connect(argv[1], argv[2])) < 0) {
		perror("could not connect");
		return (2);
	}

	retval = rx_execve(sock, argv[3], &argv[3], (char **)NULL);
	/* retval = rx_execve(sock, argv[3], &argv[3], envp); */

	dupshell(sock);

	return (0);
}

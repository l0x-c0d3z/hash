#include <asm/unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

/*
 * memory stuffs
 */

static const char copyright[] =
	"Portions of this work are derived from The Standard C Library, "
	"copyright (c) 1992 by P.J. Plauger, published by Prentice-Hall, "
	"and are used with permission.";

static int errno;

char *
strcat(char *s1, const char *s2)
{
	char	* s;

	for (s = s1; *s != '\0'; ++s)
		;

	for (; (*s = *s2) != '\0'; ++s, ++s2)
		;

	return s1;
}

char *
strcpy(char *s1, const char *s2)
{
	char	* s = s1;

	for (s = s1; (*s++ = *s2++) != '\0'; )
		;

	return (s1);
}

size_t
strlen(const char *s)
{
	const char	* sc = s;

	for (sc = s; *sc != '\0'; ++sc)
		;
	return (sc -s);
}

void *
memcpy(void *s1, const void *s2, size_t n)
{
	char	* su1;
	const char * su2;

	for (su1 = s1, su2 = s2; 0 < n; ++su1, ++su2, --n)
		*su1 = *su2;

	return (s1);
}

void *
memset(void *s, int c, size_t n)
{
	const unsigned char	uc = c;
	unsigned char	* su;

	for (su = s; 0 < n; ++su, --n)
		*su = uc;

	return (s);
}


/*
 * Syscalls 
 */
_syscall2(int,open,const char *,fname,int,flags)
_syscall1(int,close,int,fd)
_syscall3(ssize_t,read,int,fd,void *,buf,size_t,n)
_syscall6(void *,mmap2,void *,start,size_t,length,int,prot,int,flags,int,fd,off_t,offset)
_syscall2(int,munmap,void *,start,size_t,length)
_syscall3(int,mprotect,void *,addr,size_t,len,int,prot)
_syscall1(int,brk,void *,end_data_segment)
_syscall2(int,fstat64,int,fd,struct stat64 *,buf)
/* _syscall2(int,stat64,const char *,fname,struct stat64 *,buf) */

void *
mmap(void *start, size_t len, int prot, int flags, int fd, off_t off)
{
	return mmap2(start, len, prot, flags, fd, off);
}

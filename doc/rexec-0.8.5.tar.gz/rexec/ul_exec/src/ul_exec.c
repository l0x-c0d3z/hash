/*-
 * Copyright (c) 2003 the grugq
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the grugq
 * 4. The name of the author may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */


#include <stdio.h>
#include <alloca.h>
#include <elf.h>

#include <ul_execP.h>

static void ul_exec_common(void *ELF_buf, ul_args_t *argv, ul_args_t *envp);

void
ul_exec(void *ELF_buf, int argc, char **argv, char **envp)
{
	ul_args_t	* args, * env = NULL;


	(void) alloca(2048); /* some stack padding so we dont hurt ourselves */

	if ((args = ul_save_args(argc, argv)) == NULL)
		return;

	if (envp) {
		if ((env = ul_save_args(0, envp)) == NULL) {
			ul_release_args(args);
			return;
		}
	}

	ul_exec_common(ELF_buf, args, env);
}

/*
**
** #define set_stack(ebp, esp)	\
** 	asm("\tmovl %0, %%ebp\n"	\
** 	    "\tmovl %1, %%esp\n"	\
** 	     :: "r"(ebp), "r"(esp))
**
*/

#define set_stack(esp) asm("\tmovl %0, %%esp\n" :: "r"(esp))

#define jmp_addr(addr) asm("\tjmp  *%0\n" :: "r" (addr))

#define	STACK_TOP	((void *)0xC0000000)

static void
ul_exec_common(void *ELF_buf, ul_args_t *argv, ul_args_t *envp)
{
	Elf32_Ehdr	* elf = NULL, * interp = NULL;
	void	(*entry)();
	void	* esp;


	/* clean up the address space */
	ul_map_down();

	/* load the main binary, and if required the dynamic linker */
	if (ul_load_elf(ELF_buf, &elf, &interp)) {
		ul_release_args(argv);
		ul_release_args(envp);
		return;
	}

	/* initialize the stack. */
	esp = ul_setup_stack(STACK_TOP, argv, envp, elf, interp);

	/* XXX this breaks with -fomit-frame-pointer, probably because of
	 * what we do to the stack above. */
#if 0
	 ul_release_args(argv);
	 ul_release_args(envp);
#endif

	if (NULL == esp)
		return;

	entry = interp ? (void(*)())(((char *)interp) + interp->e_entry) :
			 (void(*)())elf->e_entry;

	/* set the %esp */
	set_stack(esp);

	/* transfer control to the new image */
	jmp_addr(entry);

	/* if we get here, there are massive fucking problems, for a start
	 * our stack is fucked up, and we can't return(). Just crash out. */
}

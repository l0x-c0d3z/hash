/*-
 * Copyright (c) 2003 the grugq
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the grugq
 * 4. The name of the author may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <elf.h>


typedef struct ul_args {
	size_t	size;
	int	cnt;
	char	tab[1];
} ul_args_t;

#define allocate(size)	\
      mmap(0, (size), PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0)

ul_args_t *
ul_save_args(int argc, char **argv)
{
	struct ul_args	* args;
	char	* str;
	size_t	  len;
	int	  i;
	

	for (i = 0, len = 0; i < argc; i++)
		len += strlen(argv[i]) + 1;

	args = allocate(len + sizeof(*args));

	args->size = len;
	args->cnt = argc;

	for (i = 0, str = args->tab; i < argc; i++, str += strlen(str) + 1)
		strcat(str, argv[i]);

	return (args);
}

void
ul_release_args(ul_args_t *args)
{
	munmap((void *)args, args->size + sizeof(*args));
}

#define	NUM_OF_AUX	7

void *
ul_setup_stack(void * stack_top, ul_args_t *args, ul_args_t *envp,
		Elf32_Ehdr * elf, Elf32_Ehdr *interp)
{
	Elf32_auxv_t	* aux;
	char	* addr, * str, **ptr, * esp;
	int	  argsize, i;

	argsize = 4; /* argc */

	argsize += args->cnt * sizeof(char *); /* argv */
	argsize += 4; /* NULL */

	argsize += envp->cnt * sizeof(char *); /* envp */
	argsize += 4; /* NULL */

	argsize += sizeof(Elf32_auxv_t) * NUM_OF_AUX;

	argsize += args->size; /* argv strings */
	argsize += 4; /* argv_strings [NULL] envp_strings */

	argsize += envp->size; /* envp strings */
	argsize += 4; /* NULL */

	argsize += 4; /* stack_top == NULL */

	/* align to a 4 byte boundary | XXX kernel uses 16 byte alignment */
	argsize = (argsize + 3) & ~3;

	/* END CALCULATIONS, BEGIN SETTING UP THE STACK */
	esp = (char *)stack_top - argsize;

	memcpy(esp, &args->cnt, sizeof(int));	/* argc */

	ptr = (char **)(esp + sizeof(int)); /* ptr = &argv[0] */

	/* addr = [argv][0][envp][0][auxv] */
	addr = (char *)ptr + (((args->cnt + 1) * sizeof(char *)) +
			      ((envp->cnt + 1) * sizeof(char *)) +
			      (NUM_OF_AUX * sizeof(Elf32_auxv_t))+
						 sizeof(char *));

	/* set up argv[] and the argv strings */
	for (i = 0, str = args->tab; i < args->cnt; i++, str += strlen(str)+1) {
		strcpy(addr, str);

		*ptr++ = addr;
		addr += strlen(str) + 1;
	}
	*ptr++ = NULL;

	/* set up envp[] and the envp strings */
	for (i = 0, str = envp->tab; i < envp->cnt; i++, str += strlen(str)+1) {
		strcpy(addr, str);

		*ptr++ = addr;
		addr += strlen(str) + 1;
	}
	*ptr++ = NULL;
	aux = (Elf32_auxv_t *) ptr;
	
	/* setup the AUXV */
#define	NEW_AUX_ENT(nr, id, val)	\
	((aux[ (nr) ].a_type = (id)), (aux[ (nr) ].a_un.a_val = (long)(val)))

	NEW_AUX_ENT( 6, AT_NULL, 0);
	NEW_AUX_ENT( 5, AT_PAGESZ, 4096);
	NEW_AUX_ENT( 4, AT_PHDR, (char *)elf + elf->e_phoff);
	NEW_AUX_ENT( 3, AT_PHNUM, elf->e_phnum);
	NEW_AUX_ENT( 2, AT_BASE, interp);
	NEW_AUX_ENT( 1, AT_FLAGS, 0);
	NEW_AUX_ENT( 0, AT_ENTRY, elf->e_entry);

	return ((void *)esp);
}

#if 0
static void
print(void *args)
{
	char	**argv;
	int	  argc, i;


	argc = *((int *)args);
	argv = (char **) &(((int *)args)[1]);

	fflush(stdout);
	printf("entering print\n");

	for (i = 0; i < argc; i++) {
		printf("argv[%d] = \"%s\"\n", i, argv[i]);
		fflush(stdout);
	}

	return;
}

static void
print_args(struct ul_args *args)
{
	char	* str;
	int	  i;


	for (i = 0, str = args->tab; i < args->cnt; i++) {
		fprintf(stderr, "%d -> \"%s\"\n", i, str);
		str += strlen(str) + 1;
	}
}

int
main(int argc, char **argv, char **envp)
{
	struct ul_args	* args, * envpp;
	char	* stack_top, * esp;
	Elf32_Ehdr	elf, interp;


	stack_top = allocate(4096);
	stack_top += (4096 - 4);

	args = ul_save_args(argc, argv);
	envpp = ul_save_args(0, NULL);

	print_args(args);

	fprintf(stderr, "stack_top: %p\n", stack_top);
	esp = ul_setup_stack(stack_top, args, envpp, &elf, &interp);

	print(esp);

	return (0);
}
#endif

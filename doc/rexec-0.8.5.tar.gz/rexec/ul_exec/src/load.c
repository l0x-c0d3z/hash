/*-
 * Copyright (c) 2003 the grugq
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the grugq
 * 4. The name of the author may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */


#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <elf.h>



#define	is_loaded(p)	((p)->p_type == PT_LOAD ? 1 : 0)
#define	is_txt_segt(p)	((is_loaded(p)) && (p)->p_flags == (PF_X|PF_R))
#define	is_data_segt(p)	((is_loaded(p)) && (p)->p_flags == (PF_W|PF_R))

#define	FLAGS	(MAP_PRIVATE|MAP_ANONYMOUS)

#define	ALIGN(k, v)	(((k)+((v)-1))&(~((v)-1)))

static Elf32_Ehdr *
load_elf_buf(void *elf_buf)
{
	Elf32_Ehdr *e = (Elf32_Ehdr *) elf_buf;
	Elf32_Phdr *ptab = (Elf32_Phdr *) ((char *)elf_buf + e->e_phoff);
	Elf32_Phdr *p;
	size_t	  tot_len = 0;
	char	* ptr, * base = NULL;
	int	  i, flags;


	/* we could use e->e_type, but this way reduces our code requirement */
	for (i = 0, p = ptab; i < e->e_phnum; i++, p++) { 
		if (!is_loaded(p))
			continue;
		if (is_txt_segt(p))
			base = (char *)p->p_vaddr;
		tot_len += ALIGN(p->p_memsz, p->p_align);
	}

	flags = base ? (FLAGS|MAP_FIXED) : FLAGS;

	if ((ptr = mmap(base, tot_len, PROT_NONE, flags, -1, 0)) == MAP_FAILED)
		return NULL;

	for (i = 0, p = ptab; i < e->e_phnum; i++, p++) {
		void	* load_addr;
		size_t	  len;

		if (!is_loaded(p))
			continue;

		flags = 0;

		/* to reduce the code size we could rely on the fact that in 
		 * implementation, the PF_ flags are the same as PROT_ */
		if (p->p_flags & PF_X)
			flags |= PROT_EXEC;
		if (p->p_flags & PF_W)
			flags |= PROT_WRITE;
		if (p->p_flags & PF_R)
			flags |= PROT_READ;

		/* a very ugly way of figuring out what the base load address
		 * of this segment is. */
		load_addr = ptr + (((char *)p->p_vaddr-base)&~(p->p_align-1));
		len = ALIGN(p->p_memsz, p->p_align);

		if (mprotect(load_addr, len, PROT_WRITE)) {
			munmap(p, tot_len);
			return (NULL);
		}

		/* We need the exact load address, not the rounded down
		 * version. Otherwis we copy to a garbage location.. */
		memcpy((void *)(ptr + ((char *)p->p_vaddr - base)),
				(char *)elf_buf + p->p_offset, p->p_filesz);

		if (mprotect(load_addr, len, flags)) {
			munmap(p, tot_len);
			return NULL;
		}
	}

	e = (Elf32_Ehdr *) ptr;

	return (e);
}

static Elf32_Ehdr *
load_linker(const char *fname)
{
	Elf32_Ehdr	* e;
	struct stat64	st;
	char	* buf;
	int	  fd;


	if ((fd = open(fname, O_RDONLY)) < 0) {
		return NULL;
	}

	if (fstat64(fd, &st)) {
		close(fd);
		return NULL;
	}

	buf = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
	if (buf == MAP_FAILED) {
		close(fd);
		return (NULL);
	}

	if ((e = load_elf_buf(buf)) == NULL) {
		close(fd);
		return (NULL);
	}
	
	munmap(buf, st.st_size);
	close(fd);

	return (e);
}

int
ul_load_elf(void *ELF_buf, Elf32_Ehdr **elf, Elf32_Ehdr **interp)
{
	Elf32_Ehdr	* e, * ei = NULL;
	Elf32_Phdr	* p, *ptab;
	int	  i;


	e = (Elf32_Ehdr *)ELF_buf;
	ptab = (Elf32_Phdr *)((char *)ELF_buf + e->e_phoff);

	/* check for a dynamic linker, and if there is one, load it */
	for (i = 0, p = ptab; i < e->e_phnum; i++, p++)
		if (p->p_type == PT_INTERP) {
			if ((ei=load_linker((char*)ELF_buf+p->p_offset))==NULL)
				return (-1);
			break;
		}

	if ((e = load_elf_buf(ELF_buf)) == NULL)
		return (-1);

#define	segt_size(p)	((size_t)((p)->p_vaddr + (p)->p_memsz))
#define	load_addr(e)	((char *)(((e)->e_type == ET_DYN) ? (e) : NULL))

	/* initialize the heap for later use. */
	for (i = 0, p = ptab; i < e->e_phnum; i++, p++)
		if (is_data_segt(p))
			brk(load_addr(e) + segt_size(p));

	if (elf)
		*elf = e;
	if (interp)
		*interp = ei;

	return (0);
}

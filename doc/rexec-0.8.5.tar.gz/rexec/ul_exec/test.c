#include <stdio.h>
#include <unistd.h>
#include <string.h>

#define	hello	"Hello World!\n"

int
main(void)
{
	write(1, hello, strlen(hello));
	return (0);
}

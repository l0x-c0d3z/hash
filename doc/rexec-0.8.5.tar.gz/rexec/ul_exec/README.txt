			userland exec

       void ul_exec(void *ELF_buf, int argc, char **argv);

This function will map down the current process image, and set up the ELF
binary stored in 'ELF_buf' for execution as if it had been called via exec().
The ELF_buf must be a mmap()ed buffer because ul_exec() alters the stack.

Diet libc is required to make this compile and link. 

When stripping this down for shellcode remember that much of the bulk within
this code comes from things like support for environmental variables, and
dynamically determining the process' address space mappings. Much of this can
be hardcoded or stripped out to make the code much tighter. I've gotten
dynamic versions of this code down to 2048 bytes, but I think it can be made
smaller for specific targets without any problems.

peace,

grugq


ps. this won't work at all for threaded programs. You'll need to kill all 
the other threads first, before you unload the main .text with ul_exec().
